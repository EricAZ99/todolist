let todo = {
    template: `<div>
    <section class="todoapp">
            <header>
                <h1>Todos</h1>
                <input type="text" class="new-todo" placeholder="Ajouter une tâche" v-model="newTodo" @keyup.enter="addtodo">
            </header>
            <div class="main">
                <ul class="todo-list">
                    <li class="todo" v-for="todo in filteredTodos" :class="{completed: todo.completed}">
                        <div class="view">
                            <input type="checkbox" v-model="todo.completed" class="toggle"/>
                            <label>{{ todo.name }}</label>
                        </div>
                    </li>
                </ul>
            </div>
            <footer class="footer">
                <span class="todo-count"><strong>{{ remaining }}</strong>tâche à faire</span>
                <ul class="filters">
                    <li><a href="#" :class="{selected: filter === 'all'}" @click.prevent="'all'">Toutes</a></li>
                    <li><a href="#" :class="{selected: filter === 'todo'}" @click.prevent="'todo'">A faire</a></li>
                    <li><a href="#" :class="{selected: filter === 'done'}" @click.prevent="'done'">Faites</a></li>
                </ul>
            </footer>
    </section>
    </div>`,

    data() {
        return {
            todos: [{
                name: 'Tâche de test',
                completed: false,
            }],
            newTodo: '',
            filter: 'all',
        }
    },

    methods: {
        addtodo() {
            this.todos.push({
                completed: false,
                name: this.newTodo
            });
            this.newTodo = '';
        }
    },

    computed: {
        remaining() {
            return this.todos.filter(todo => !todo.completed).length;
        },
        
        filteredTodos() {
            if(this.filter === 'todo') {
                return this.todos.filter(todo => !todo.completed)
            } else if (this.filter === 'done') {
                return this.todos.filter(todo => todo.completed)
            }
            return this.todos;
        }
    }
}
new Vue({
    el: '#app',
    data: {
        message: "ok",
    },
    components: {
        todo,
    }
})